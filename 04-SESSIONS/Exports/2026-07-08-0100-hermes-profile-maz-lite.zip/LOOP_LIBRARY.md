# LOOP_LIBRARY

## Loop rules
Every loop must have: goal, context source, max scope, tools allowed, approval gates, stop condition, final summary path.

## Fast fix loop
1. Verify cwd. 2. Read error. 3. Inspect minimal files. 4. Propose/apply small fix. 5. Verify. 6. Summarise.

## Repo build loop
1. `git status`. 2. Inspect README/package.json/config. 3. Plan smallest useful vertical slice. 4. Implement. 5. Test/build. 6. Save summary.
Approval before install, env changes, migrations, deploy, push.

## Research-to-build loop
1. Research official docs/GitHub/examples if needed. 2. Extract patterns. 3. Convert into build requirements. 4. Write implementation prompt or patch. 5. Save useful findings.

## Obsidian memory loop
1. Update project card only if durable. 2. Add session summary. 3. Add decision if durable. 4. Avoid raw logs.

## Prompt upgrade loop
1. Read `PROMPT_INSPIRATION.md`. 2. Search similar summaries only if useful. 3. Output one copy-paste prompt.

## Session cleanup loop
1. Identify current session. 2. List other sessions. 3. Summarise other sessions. 4. Save cleanup to Obsidian. 5. Close other sessions only if requested. 6. Email only if requested and verified. See `SESSION_CONTROL.md`.

## Profile export loop
1. Build clean profile export. 2. Redact by default. 3. Save to Obsidian. 4. Email only after file write verified. 5. Fallback to markdown on failure. See `EXPORT_POLICY.md`.
