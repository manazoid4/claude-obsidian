# SESSION_CONTROL

## Purpose
Rules for compacting, summarising, closing, and emailing Hermes session cleanup reports.

## Trigger phrases
close all other sessions / close other sessions / compact and close other sessions / summarise and close sessions / session cleanup / compact sessions and email me / close everything except this

## Rules
- never close the current active session unless explicitly requested
- dry-run first when unsure
- summarise before closing when compacting
- save summary to Obsidian before email
- email only when requested
- do not claim close/email success unless verified (Resend response must include `id`)

## Summary path
`C:\Users\manaz\Desktop\Obsidian Main Vault\04-SESSIONS\Session Cleanups\`

## Email
To: manazoid4@gmail.com
Subject: `Hermes Session Cleanup � YYYY-MM-DD HH:mm`

## Implementation
See skill `session-control`. Template: `04-SESSIONS\_TEMPLATE_SESSION_CLEANUP.md`.
