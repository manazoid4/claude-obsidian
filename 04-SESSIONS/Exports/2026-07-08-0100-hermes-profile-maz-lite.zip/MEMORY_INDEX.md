# MEMORY_INDEX

## Purpose
Hermes' memory router for the `maz-lite` profile. Read this before searching Obsidian or old sessions.

## Core paths
- Vault root: `C:\Users\manaz\Desktop\Obsidian Main Vault` (repo `manazoid4/claude-obsidian`)
- Vault memory (canonical, git-tracked): `C:\Users\manaz\Desktop\Obsidian Main Vault\03-MEMORY\` � MEMORY_INDEX.md, PROJECT_INDEX.md, DECISIONS.md, USER_PROFILE.md already live there. Treat those as canonical over anything duplicated in this profile.
- Sessions: `C:\Users\manaz\Desktop\Obsidian Main Vault\04-SESSIONS\`
- This profile: `C:\Users\manaz\AppData\Local\hermes\profiles\maz-lite\`

## Source of truth hierarchy
1. Local working tree
2. GitHub repo
3. Obsidian vault `03-MEMORY/` (canonical � see above, not this profile's copies)
4. Session summaries (`04-SESSIONS/`)
5. Model memory / old chat � lowest priority

## Rules
- Local uncommitted work beats GitHub.
- GitHub/local repo files beat Obsidian for code truth.
- Obsidian explains intent, decisions, and durable preferences.
- Session history is context only, not live truth.
- If not verified, write `not verified`.

## What to read
| Need | Read first | Then |
|---|---|---|
| project state | local repo / GitHub | `PROJECTS_INDEX.md`, then vault `PROJECT_INDEX.md` |
| user preference | `memories/USER.md` | `USER_PROFILE.md` |
| project intention | vault `PROJECT_INDEX.md` | vault `DECISIONS.md` |
| prompt help | `PROMPT_INSPIRATION.md` | similar past session summary |
| previous work | latest `04-SESSIONS/` entry | repo truth |
| session cleanup | `SESSION_CONTROL.md` | `LOOP_LIBRARY.md` |

## What not to load
- whole Obsidian folders
- raw old sessions
- giant logs
- old exports as truth
- temporary troubleshooting as permanent memory

## Last updated
2026-07-08 (maz-lite profile creation)
