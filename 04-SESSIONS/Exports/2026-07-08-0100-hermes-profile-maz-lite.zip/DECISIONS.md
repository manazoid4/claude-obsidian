# DECISIONS

Profile-scoped decisions for `maz-lite`. Broader/company decisions live in the Obsidian vault `03-MEMORY\DECISIONS.md`.

## Accepted

### 2026-07-08 � Create maz-lite profile
- Context: old default-profile SOUL/MEMORY/USER export was flat, mixed durable prefs with one-off troubleshooting, caused token bloat and hallucination risk.
- Decision: create a separate lightweight profile (`hermes profile create maz-lite`) instead of overwriting the default profile.
- Consequence: Hermes can use `maz-lite` for fast verified daily work; original default profile remains fully recoverable and untouched.
- Reversal condition: if profile system conflicts with Hermes internals, or Maz prefers to revert � delete via `hermes profile delete maz-lite` (default profile is never touched by this).

### 2026-07-08 � GitHub/local repos are source of truth for code
- Context: Obsidian/session memory can go stale relative to actual repo state.
- Decision: verify local/GitHub (`git status`, `gh repo list`) before project/code claims; Obsidian is for intent and durable prefs, not code state.
- Consequence: fewer hallucinations, slightly more inspection needed per task.

### 2026-07-08 � Did not duplicate the existing Obsidian MEMORY_INDEX/PROJECT_INDEX/DECISIONS system
- Context: `03-MEMORY/` in the vault already has a canonical, git-tracked, actively-maintained memory system (MEMORY_INDEX.md, PROJECT_INDEX.md, DECISIONS.md, USER_PROFILE.md) predating this task.
- Decision: this profile's docs point to those as canonical rather than re-creating parallel copies under different names.
- Consequence: single source of truth in Obsidian; this profile's `PROJECTS_INDEX.md`/`GITHUB_REPOS_INDEX.md` are a fast local cache, not a competing canon.
