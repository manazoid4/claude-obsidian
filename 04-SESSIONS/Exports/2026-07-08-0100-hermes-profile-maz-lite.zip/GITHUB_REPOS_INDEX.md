# GITHUB_REPOS_INDEX

## Purpose
Repo routing map only. Not repo truth � always verify with `git status`, `git branch --show-current`, `git remote -v` before claiming current state.

## Verified repos (via `gh repo list manazoid4`, 2026-07-08)
| Repo | Visibility | Description |
|---|---|---|
| JobFilterV1 | public | AI lead qualification for UK trades |
| mazos-ui | public | (no description set) |
| recall | public | Creative intelligence from saved posts (was "saved-brain" locally) |
| omniscribe | public | AI video translation + style transfer |
| flipsignal | private | (no description set) |
| zawiya-growth-hub | private | Zawiya Trust mission-control hub |
| JobFilter-Obsidian-Vault | private | JobFilter Obsidian knowledge vault |
| openflowkit | public | Voice dictation + AI text refinement kit |
| zawiya-knowledge-vault | private | Zawiya Trust institutional memory |
| SecureShift | private | UK SIA/security job board |
| inkweave | public | Snippet-to-book platform |
| LimitLens | private | (no description set) |
| khutba-io | public | Live khutba translation/subtitles |
| AgentDock | public | Marketing site |
| claude-obsidian | public | Claude + Obsidian wiki vault (this memory system) |

## Not in this list / not verified
- Hermes itself is `NousResearch/hermes-agent` (upstream, not manazoid4-owned)
- "FlowLens" � no matching repo found

## Rules
- Local dirty working tree beats GitHub.
- README/package.json/config files beat old memory.
- Full project index with local paths: `PROJECTS_INDEX.md`.
