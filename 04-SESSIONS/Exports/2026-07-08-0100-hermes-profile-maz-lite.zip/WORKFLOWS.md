# WORKFLOWS

Reusable commands, cleaned from old default-profile memory. Kept only what's still generally useful � not stale project-specific one-offs.

## Hermes dashboard first run
```
cd C:/Users/manaz/AppData/Local/hermes/hermes-agent && npm install --workspace web && npm run build -w web
```
If `lucide-react` missing: `cd web && npm install lucide-react`.

## Next.js/Tailwind scaffold notes
- Use `.mjs` for PostCSS/ESM configs.
- Avoid forcing package-wide `"type":"module"`.
- Check ports before starting localhost.
- After compile fixes, restart dev server and verify in browser.

## GitHub push rule
Always ensure `node_modules/` is in `.gitignore` before first push of a new repo � prevents large-file rejections.

## CLI command style
One-line commands with cwd included, exact paths, no placeholders when possible.

## Obsidian vault scanning
Canonical vault: `C:\Users\manaz\Desktop\Obsidian Main Vault`. Search `03-MEMORY/` and `04-SESSIONS/` for Maz's intent and repeated patterns before broad vault search.

## Context compression (general, not MAZos-only)
For long-running project work, dump active state to a `STATE.md` in the project's own working dir rather than relying on chat history; read it on session start.
