# PROMPT_INSPIRATION

## Purpose
Use when Maz asks for build prompts, research prompts, repo prompts, Hermes prompts, or agent loop prompts.

## Maz's preferred prompt style
- copy-pasteable, direct, ambitious but controlled, practical
- includes inspection/research, build phase, verification checks
- includes Obsidian memory update, final report, approval gates for risky actions

## Prompt formula
1. Mission 2. Context 3. Constraints 4. Inspect/research 5. Plan 6. Build 7. Verify 8. Save memory 9. Final report 10. Approval checklist

## Modules
### Manual control
No destructive changes without approval. Show diff before overwrite. Separate verified from recommended.

### GitHub source of truth
Inspect repo before claims. Use README/package.json/git status. Don't rely on old memory for code.

### Obsidian memory
Read `MEMORY_INDEX.md` first. Read one relevant note. Save concise summaries only.

### Verification
Run tests/build/lint if available. Report exact output. Mark failures clearly.

### Email summary
Write summary first. Verify file exists. Then email. Fallback to markdown if email fails.

### Session cleanup
Keep current session open. Compact other sessions. Save summary to Obsidian. Close only explicitly targeted sessions.
