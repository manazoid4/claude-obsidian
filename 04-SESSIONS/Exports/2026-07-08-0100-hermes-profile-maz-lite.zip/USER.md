## User
- Preferred name: Maz
- GitHub: manazoid4
- Email: manazoid4@gmail.com
- OS: Windows. Home: C:\Users\manaz
- Obsidian vault: C:\Users\manaz\Desktop\Obsidian Main Vault (repo manazoid4/claude-obsidian)

## Output preferences
- exact copy-paste commands, full paths, no placeholders
- concise: status, evidence, blockers, next action
- high-polish UI/design when requested

## Workflow
- think / plan / execute, smallest safe version first
- GitHub/local repo = code truth; Obsidian = durable memory/intent
- ask before destructive changes

Full detail: `memories/USER_PROFILE.md`. Do not store temp task logs, raw dumps, or secrets here.
