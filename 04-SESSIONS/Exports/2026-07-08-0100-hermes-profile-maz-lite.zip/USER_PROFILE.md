# USER_PROFILE

## User
- Preferred name: Maz
- GitHub: manazoid4
- Email for summaries: manazoid4@gmail.com

## System
- OS: Windows
- Home path: C:\Users\manaz
- Obsidian vault: C:\Users\manaz\Desktop\Obsidian Main Vault (repo manazoid4/claude-obsidian)

## Output preferences
- exact copy-paste commands
- include cwd/full paths when useful
- no vague placeholders
- concise status, evidence, blockers, next action
- high-polish UI/design when requested
- prefer useful build prompts over theory

## Workflow preferences
- think / plan / execute
- smallest safe version first
- use GitHub/local files as source of truth
- use Obsidian for durable memory
- save useful summaries to Obsidian
- ask before destructive changes
- use OSS/GitHub examples for inspiration when useful

## Do not store here
- temporary task logs
- raw session dumps
- secrets
- old troubleshooting unless still reusable
