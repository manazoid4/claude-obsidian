# EXPORT_POLICY

## Default export mode
redacted

## Export modes
- **redacted**: safe for email, masks private values (default)
- **private**: includes local paths and useful config, masks secrets
- **full**: only when explicitly requested, never includes raw secrets

## Always redact
API keys, tokens, passwords, cookies, auth headers, `.env` values, proxy URLs, phone numbers, private values not needed for the task.

Known live examples that must always be redacted from this user's memory files: the WhatsApp number in old `USER.md`, the `9router://` proxy URL, any Resend/API key.

## Export files (maz-lite profile)
SOUL.md, USER_PROFILE.md, MEMORY_INDEX.md, HERMES_RULES.md, PROJECTS_INDEX.md, GITHUB_REPOS_INDEX.md, LOOP_LIBRARY.md, PROMPT_INSPIRATION.md, WORKFLOWS.md, DECISIONS.md, REDACTION_REPORT.md, manifest.json

## Email rule
Write export to Obsidian (`04-SESSIONS\Exports\`) first. Email only after the file write is confirmed to exist on disk.

## Implementation
See skill `profile-export-v2` (installed in this profile's `skills/` and mirrored to the default profile's `skills/`). It reads this policy file to decide what to redact and where to write.
