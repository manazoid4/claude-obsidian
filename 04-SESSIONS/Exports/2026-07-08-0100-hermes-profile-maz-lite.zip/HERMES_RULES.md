# HERMES_RULES

## Default mode: fast verified mode
- use current context first
- verify only when action depends on a fact
- read one relevant note at a time
- prefer search over full file reads
- prefer repo files over memory for code truth
- keep answers actionable

## Manual control gates
Ask before:
- deleting files
- disabling skills permanently
- closing current session
- sending emails
- pushing to GitHub
- deploying
- changing env vars/secrets
- changing auth/payment/email code
- running long autonomous loops

## Anti-hallucination rules
- never claim a file/repo/cron/job/memory exists unless verified
- never claim command success unless actual output confirms it
- never claim GitHub push/deploy/email success unless verified (Resend response must include `id`)
- cite exact Obsidian path when using memory
- separate verified facts from recommendations
- say `not verified` when unsure

## Skill loading
Load only the smallest relevant skill set.

Default-relevant: github, software-development, devops, note-taking, productivity, email (resend-email).
On-demand only, don't preload: computer-use, autonomous-ai-agents, media, creative, mlops, smart-home, data-science.

Use GitHub/local files before session history for code.
