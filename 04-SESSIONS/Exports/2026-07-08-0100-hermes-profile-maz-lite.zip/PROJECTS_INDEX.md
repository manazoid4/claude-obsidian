# PROJECTS_INDEX

## Purpose
Lightweight routing map for Maz's active projects. Not code truth � verify repo/local files before claims. Canonical version with fuller history: Obsidian vault `03-MEMORY\PROJECT_INDEX.md`.

Verified 2026-07-08 via `gh repo list manazoid4` + local `git remote -v`.

## Projects

| Project | GitHub repo | Local path | Notes |
|---|---|---|---|
| JobFilter | `manazoid4/JobFilterV1` (public) | `C:\Users\manaz\Desktop\JobFilter`, `C:\Users\manaz\Desktop\jobfilter\jobfilterv1` (both same remote) | #1 priority, UK trades lead intel |
| MAZos | `manazoid4/mazos-ui` (public) | `C:\Users\manaz\mazos-ui`, `C:\Users\manaz\Projects\mazos-ui` | AI command cockpit |
| Recall / Saved Brain | `manazoid4/recall` (public) | `C:\Users\manaz\saved-brain` | repo renamed from saved-brain -> recall; closest to paying |
| InkWeave | `manazoid4/inkweave` (public) | `C:\Users\manaz\Desktop\inkweave` | AI snippet-to-book, UK-first |
| OpenFlowKit | `manazoid4/openflowkit` (public) | `C:\Users\manaz\Desktop\openflowkit` | voice dictation, AGPL |
| FlipSignal | `manazoid4/flipsignal` (private) | `C:\Users\manaz\Desktop\flipsignal` | AI marketplace arbitrage |
| SecureShift | `manazoid4/SecureShift` (private) | `C:\Users\manaz\Desktop\secure-shift` | UK SIA job board |
| Zawiya Growth Hub | `manazoid4/zawiya-growth-hub` (private) | `C:\Users\manaz\Desktop\zawiya-growth-hub` | Notion hub + ops, not a web app |
| OmniScribe | `manazoid4/omniscribe` (public) | `C:\Users\manaz\Desktop\omniscribe` | AI video translation |
| claude-obsidian | `manazoid4/claude-obsidian` (public) | `C:\Users\manaz\claude-obsidian`, `C:\Users\manaz\Desktop\Obsidian Main Vault` | the memory vault itself |
| Hermes | `NousResearch/hermes-agent` (upstream fork, not user's own repo) | `C:\Users\manaz\AppData\Local\hermes\hermes-agent` | local agent; 28 commits behind upstream/main, 1 local carried commit � `not verified` whether that carried commit is intentional |
| LimitLens | `manazoid4/LimitLens` (private) | `C:\Users\manaz\Desktop\LimitLens` | Electron dev tool � possibly same concept as "FlowLens" mentioned in earlier sessions; name mismatch `not verified` |
| khutba-io | `manazoid4/khutba-io` (public) | `C:\Users\manaz\Desktop\khutba-io` | sermon translation, Deepgram+Google Translate |
| AgentDock | `manazoid4/AgentDock` (public) | `C:\Users\manaz\Desktop\AgentDock` | marketing site, backend not built |

## Not verified
- "FlowLens" (screen/process capture tool) � no matching repo in `gh repo list manazoid4`. May be planned/renamed to LimitLens, or not yet created.
