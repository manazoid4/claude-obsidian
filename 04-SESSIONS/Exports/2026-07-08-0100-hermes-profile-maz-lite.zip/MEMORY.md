Read `memories/MEMORY_INDEX.md` first for routing to project/prompt/loop docs � this file holds only durable, always-true facts.
�
Source of truth: local working tree > GitHub repo > Obsidian project memory > session summaries > model memory. Never claim file/repo/cron/email/deploy success without tool-verified output.
�
Manual CLI commands to Maz: exact one-line copy-paste, full paths, no placeholders.
�
node_modules/ must always be gitignored before first push of a new repo.
�
UI/design tasks: high-polish output expected, not bare functional skeletons.
